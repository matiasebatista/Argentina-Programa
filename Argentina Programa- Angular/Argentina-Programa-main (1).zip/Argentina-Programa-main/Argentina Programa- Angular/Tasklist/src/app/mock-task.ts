import {Task} from "../app/Task"

export const TASKS: Task[] =[

]