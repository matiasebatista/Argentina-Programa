export interface Task {
    id?: number;
    text: string;
    day:  Date;
    reminder: boolean;
}